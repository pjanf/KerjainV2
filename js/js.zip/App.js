/* @flow */

import React from "react";

import { Platform } from "react-native";
import { Root } from "native-base";
import { StackNavigator, TabNavigator } from "react-navigation";

import Drawer from "./Drawer";
import Register from "./components/register/";
import Home from "./components/home/";
import Education from "./components/register/education";
import EducationAdd from "./components/register/educationAdd";
import WorkExperience from "./components/register/workExperience";
import WorkExperienceAdd from "./components/register/workExperienceAdd";
import MyProfile from "./components/myProfile/";
import JobDetail from "./components/jobDetail/";
import Notification from "./components/home/notification";
import JobSearch from "./components/home/jobSearch";
import ForgotPassword from "./components/forgotPassword/";

const AppNavigator = StackNavigator(
    {
        Drawer: { screen: Drawer },
        Register: { screen: Register },
        Home: { screen: Home },
        Education: { screen: Education },
        EducationAdd: { screen: EducationAdd },
        WorkExperience: { screen: WorkExperience },
        WorkExperienceAdd: { screen: WorkExperienceAdd },
        MyProfile: { screen: MyProfile },
        JobDetail: { screen: JobDetail },
        Notification: { screen: Notification },
        JobSearch: { screen: JobSearch },
        ForgotPassword: { screen: ForgotPassword },
    },
    {
        initialRouteName: "Drawer",
        headerMode: "none",
    }
);

export default () =>
    <Root>
        <AppNavigator />
    </Root>;
